const express = require('express');
const app = express();
const PORT = 3000;

// ------------------------
// Logging Middleware
// ------------------------
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.originalUrl}`);
  next();
});

// ------------------------
// Bearer Token Middleware
// ------------------------
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(401).json({ error: 'Authorization header missing' });
  }

  const tokenParts = authHeader.split(' ');

  if (tokenParts.length !== 2 || tokenParts[0] !== 'Bearer') {
    return res.status(400).json({ error: 'Malformed authorization header' });
  }

  const token = tokenParts[1];

  if (token !== 'mysecrettoken') {
    return res.status(403).json({ error: 'Invalid or missing token' });
  }

  next(); // Token is valid, continue to the route
};

// ------------------------
// Routes
// ------------------------

// Public route (no token required)
app.get('/public', (req, res) => {
  res.json({ message: 'Welcome to the public route!' });
});

// Protected route (token required)
app.get('/protected', authenticateToken, (req, res) => {
  res.json({ message: 'Access granted to protected route!' });
});

// ------------------------
// Start Server
// ------------------------
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

# 🌩️ Practice 3 - AWS Full Stack Deployment with Load Balancer

## Overview
This project demonstrates deploying a simple React (frontend) and Node.js/Express (backend) full stack application on AWS with load balancing for scalability and fault tolerance.

## Steps Summary
1. **Launch EC2 instances** for backend and frontend.
2. **Deploy backend** on multiple EC2 instances using Node.js.
3. **Deploy frontend** using Nginx on a separate EC2 instance.
4. **Set up Application Load Balancer (ALB)** to route traffic between backend instances.
5. **Configure security groups, VPC, and Route 53 (optional)** for custom domain routing.

## To Run Locally
### Backend
```bash
cd backend
npm install
npm start
```
Access: http://localhost:5000/api

### Frontend
```bash
cd frontend
npm install
npm start
```
Access: http://localhost:3000

## Deployment Output
✅ Full stack app running via ALB DNS URL  
✅ Load balancing ensures traffic distribution and high availability

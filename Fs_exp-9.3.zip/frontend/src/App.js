import React from "react";

function App() {
  const [message, setMessage] = React.useState("Loading from backend...");

  React.useEffect(() => {
    fetch("http://<ALB-DNS>/api")
      .then((res) => res.text())
      .then((data) => setMessage(data))
      .catch(() => setMessage("Error connecting to backend"));
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🌩️ Full Stack App on AWS</h1>
      <p>{message}</p>
    </div>
  );
}

export default App;

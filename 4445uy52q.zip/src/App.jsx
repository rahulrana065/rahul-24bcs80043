import React from "react";
import ProductCard from "./ProductCard";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Product List</h1>

      <div style={{ display: "flex", flexWrap: "wrap" }}>
        <ProductCard name="Wireless Headphones" price={49.99} inStock={true} />
        <ProductCard name="Smart Watch" price={89.99} inStock={false} />
        <ProductCard name="Gaming Mouse" price={29.99} inStock={true} />
        <ProductCard name="Mechanical Keyboard" price={79.99} inStock={true} />
      </div>
    </div>
  );
}

export default App;

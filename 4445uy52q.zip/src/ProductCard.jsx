import React from "react";

function ProductCard(props) {
  const { name, price, inStock } = props;

  return (
    <div style={styles.card}>
      <h2>{name}</h2>
      <p>Price: ${price}</p>
      <p style={{ color: inStock ? "green" : "red" }}>
        {inStock ? "In Stock" : "Out of Stock"}
      </p>
    </div>
  );
}

// Inline styling for simplicity
const styles = {
  card: {
    border: "1px solid #ccc",
    borderRadius: "8px",
    padding: "15px",
    width: "200px",
    textAlign: "center",
    margin: "10px",
    backgroundColor: "#f9f9f9",
    boxShadow: "2px 2px 5px rgba(0, 0, 0, 0.1)",
  },
};

export default ProductCard;

document.getElementById("categoryFilter").addEventListener("change", filterProducts);

function filterProducts() {
    // Get the selected category
    const selectedCategory = document.getElementById("categoryFilter").value;

    // Get all product elements
    const products = document.querySelectorAll(".product");

    // Loop through each product and check its category
    products.forEach(product => {
        const productCategory = product.getAttribute("data-category");

        if (selectedCategory === "all" || selectedCategory === productCategory) {
            product.style.display = "block"; // Show product
        } else {
            product.style.display = "none"; // Hide product
        }
    });
}
